import pyodbc
from flask import Flask, flash, redirect, request, session, url_for
from app.config import Config
from app.routes.auth import auth_bp
from app.routes.users import users_bp
from app.routes.user_routes import user_bp
from app.routes.va_routes import va_bp
from app.routes.pdf_routes import pdf_bp
from app.services.access_control import default_menu_access, landing_endpoint, menu_for_endpoint
from app.services.audit_log import begin_request, write_response_audit
from app.models.user_model import get_current_menu_access

def create_app():
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )

    app.config.from_object(Config)

    app.register_blueprint(auth_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(user_bp)
    app.register_blueprint(va_bp)
    app.register_blueprint(pdf_bp)

    @app.before_request
    def enforce_menu_access():
        begin_request()
        if session.get("role") == "admin":
            return None

        # Access is refreshed from the administrator's configuration so a
        # revoked menu, including Tech, disappears immediately for active users.
        if session.get("user") and session.get("user_id"):
            current_access = get_current_menu_access(session["user_id"], session.get("level"))
            if current_access is not None:
                session["menu_access"] = sorted(current_access)

        menu_key = menu_for_endpoint(request.endpoint)
        if menu_key and session.get("user"):
            # Menu access is established at login and kept in the signed
            # session. Do not query SQL Server before every page request:
            # otherwise a temporary DB connection issue blocks every menu,
            # including static pages such as Tech.
            menu_access = set(session.get("menu_access") or default_menu_access(
                session.get("level")
            ))
            if menu_key not in menu_access:
                return redirect(url_for(landing_endpoint(menu_access)))
        return None

    @app.after_request
    def record_activity(response):
        write_response_audit(response)
        return response

    @app.errorhandler(pyodbc.Error)
    def handle_database_connection_error(error):
        """Keep database outages from exposing a Flask traceback to users."""
        flash(
            "Layanan database sedang tidak tersedia. Silakan coba kembali setelah koneksi SQL Server dipulihkan.",
            "error"
        )
        if session.get("user"):
            return redirect(url_for("user.dashboard"))
        return redirect(url_for("auth.login"))

    return app
