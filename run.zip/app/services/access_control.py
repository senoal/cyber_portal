"""Menu-level authorization for non-admin portal users."""

from flask import session

MENU_OPTIONS = (
    ("dashboard", "Dashboard"),
    ("va_analysis", "VA Dashboard"),
    ("va_register", "VA Register"),
    ("pentest", "Pentest"),
    ("ip_intelligence", "IP Intelligence"),
    ("tech", "Tech"),
)
MENU_KEYS = {key for key, _ in MENU_OPTIONS}

DEFAULT_ACCESS = {
    "Internal": MENU_KEYS,
    "Eksternal": {"pentest"},
}


def default_menu_access(level):
    return set(DEFAULT_ACCESS.get(level, {"dashboard"}))


def menu_for_endpoint(endpoint):
    if endpoint in {"user.dashboard", "user.vulnerability"}:
        return "dashboard"
    if endpoint in {"user.va_analysis", "pdf.va_report"}:
        return "va_analysis"
    if endpoint and endpoint.startswith("va."):
        return "va_register"
    if endpoint and (endpoint.startswith("user.ip_") or endpoint == "user.ip_intelligence"):
        return "ip_intelligence"
    if endpoint and endpoint.startswith("user.tech"):
        return "tech"
    if endpoint and endpoint.startswith("user."):
        return "pentest"
    return None


def has_menu_access(menu_key):
    return session.get("role") == "admin" or menu_key in set(session.get("menu_access", []))


def landing_endpoint(menu_access):
    access = set(menu_access)
    for menu_key, endpoint in (
        ("dashboard", "user.dashboard"),
        ("pentest", "user.pentest"),
        ("va_analysis", "user.va_analysis"),
        ("va_register", "va.va_dashboard"),
        ("ip_intelligence", "user.ip_intelligence"),
        ("tech", "user.tech"),
    ):
        if menu_key in access:
            return endpoint
    return "auth.logout"
