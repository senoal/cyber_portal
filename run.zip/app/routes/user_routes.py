import pandas as pd
import pyodbc
from app.models.pentest_model import get_all_pentest_with_user_paginated
from flask import Blueprint, render_template, session, redirect, url_for, request, send_file
from app.models.pentest_model import get_all_pentest_with_user
from app.models.pentest_model import update_pentest_internal
from app.models.pentest_model import delete_pentest_by_id
from app.models.pentest_model import create_pentest, get_all_user_names
from app.models.pentest_model import search_pentest_internal
from app.models.pentest_model import (create_pentest_register, get_pentest_register, get_pentest_report,
    get_pentest_register_by_id, update_pentest_register, delete_pentest_register,
    get_pentest_tracker_items, create_pentest_tracker_item, update_pentest_tracker_item,
    delete_pentest_tracker_item, get_pentest_register_summary)
from app.models.pentest_model import get_all_user_names, get_all_users_for_dropdown
from app.services.ocr_engine import extract_text
from app.models.pentest_model import (
    create_pentest,
    get_pentest_by_user,
    get_pentest_by_id,
    update_pentest
)
from app.models.va_model import get_dashboard_summary
from app.models.va_model import get_dashboard_summary
from app.models.va_model import (
    get_dashboard_summary,
    get_risk_distribution,
    get_vulnerability_trend,
    get_vulnerability_by_asset_type,
    get_top5_asset_risk_score,
    get_top5_critical_vulnerability,
    get_vulnerability_severity_by_asset
)
from playwright.sync_api import sync_playwright
from werkzeug.utils import secure_filename
import os
from uuid import uuid4
from app.models.ip_intelligence_model import get_all_ip
from flask import flash
from app.models.ip_intelligence_model import (get_all_ip, insert_ip, get_ip_summary, search_ip, get_ip_by_id, update_ip)
from app.services.pentest_tracker_report import build_pentest_tracker_report
from app.services.pdf_html_converter import convert_pdf_to_html


user_bp = Blueprint('user', __name__, url_prefix='/user')


def login_required():
    return 'user' in session


# ======================
# DASHBOARD
# ======================
@user_bp.route('/dashboard')
def dashboard():
    if not login_required():
        return redirect(url_for('auth.login'))
    return render_template('user/dashboard.html')


@user_bp.route('/va_analysis')
def va_analysis():

    if not login_required():
        return redirect(url_for('auth.login'))

    date_from = request.args.get("date_from")
    date_to = request.args.get("date_to")
    asset_type = request.args.get("asset_type")
    risk_level = request.args.get("risk_level")
    pdf_mode = request.args.get("pdf")

    db_error = None
    try:
        summary = get_dashboard_summary(
            date_from,
            date_to,
            asset_type,
            risk_level
        )
        risk_distribution = get_risk_distribution(date_from, date_to, asset_type, risk_level)
        trend_data = get_vulnerability_trend(date_from, date_to, asset_type, risk_level)
        asset_chart = get_vulnerability_by_asset_type(date_from, date_to, asset_type, risk_level)
        top5_risk_asset = get_top5_asset_risk_score(date_from, date_to, asset_type, risk_level)
        top5_critical_asset = get_top5_critical_vulnerability(date_from, date_to, asset_type, risk_level)
        severity_chart = get_vulnerability_severity_by_asset(date_from, date_to, asset_type, risk_level)
    except pyodbc.Error:
        # The dashboard remains accessible when SQL Server is unreachable. The
        # normal data flow resumes automatically as soon as the connection does.
        db_error = "Data VA belum dapat dimuat karena koneksi database tidak tersedia. Silakan coba lagi beberapa saat lagi."
        summary = {"total_asset": 0, "total_vulnerability": 0, "critical": 0, "high": 0, "medium": 0, "low": 0}
        risk_distribution = {"High": 0, "Medium": 0, "Low": 0, "High_Pct": 0, "Medium_Pct": 0, "Low_Pct": 0, "Total": 0}
        trend_data = []
        asset_chart = []
        top5_risk_asset = []
        top5_critical_asset = []
        severity_chart = []
    
    return render_template(
        'user/va_analysis.html',
        summary=summary,
        risk_distribution=risk_distribution,
        trend_data=trend_data,
        asset_chart=asset_chart,
        top5_risk_asset=top5_risk_asset,
        top5_critical_asset=top5_critical_asset,
        severity_chart=severity_chart,
        db_error=db_error,
        pdf_mode=pdf_mode,
    )
    


@user_bp.route('/vulnerability')
def vulnerability():
    if not login_required():
        return redirect(url_for('auth.login'))
    return render_template('user/vulnerability.html')


@user_bp.route('/tech')
def tech():
    """Technology workspace landing page (UI-only until feature flows are added)."""
    if not login_required():
        return redirect(url_for('auth.login'))
    return render_template('user/tech.html')


@user_bp.route('/tech/pdf-to-html')
def tech_pdf_to_html():
    if not login_required():
        return redirect(url_for('auth.login'))
    return render_template('user/tech_pdf_to_html.html')


@user_bp.route('/tech/pdf-to-html/convert', methods=['POST'])
def tech_pdf_to_html_convert():
    if not login_required():
        return redirect(url_for('auth.login'))
    pdf_file = request.files.get('pdf')
    if not pdf_file or not pdf_file.filename.lower().endswith('.pdf'):
        flash('Pilih file PDF yang valid.', 'error')
        return redirect(url_for('user.tech_pdf_to_html'))
    if request.content_length and request.content_length > 25 * 1024 * 1024:
        flash('Ukuran PDF maksimal 25 MB.', 'error')
        return redirect(url_for('user.tech_pdf_to_html'))

    document_id = uuid4().hex
    output_dir = os.path.abspath(os.path.join('uploads', 'tech_html', str(session.get('user_id', 'guest'))))
    os.makedirs(output_dir, exist_ok=True)
    source_path = os.path.join(output_dir, f'{document_id}.pdf')
    html_path = os.path.join(output_dir, f'{document_id}.html')
    pdf_file.save(source_path)
    try:
        convert_pdf_to_html(source_path, html_path, secure_filename(pdf_file.filename))
    except Exception as error:
        if os.path.isfile(source_path):
            os.remove(source_path)
        flash(f'PDF tidak dapat dikonversi: {error}', 'error')
        return redirect(url_for('user.tech_pdf_to_html'))

    session['tech_html_document'] = document_id
    return render_template('user/tech_pdf_to_html.html', document_id=document_id,
                           original_name=secure_filename(pdf_file.filename))


@user_bp.route('/tech/pdf-to-html/<document_id>/view')
def tech_pdf_to_html_view(document_id):
    if not login_required():
        return redirect(url_for('auth.login'))
    if document_id != session.get('tech_html_document'):
        return 'Dokumen tidak ditemukan.', 404
    html_path = os.path.abspath(os.path.join('uploads', 'tech_html', str(session.get('user_id', 'guest')), f'{document_id}.html'))
    if not os.path.isfile(html_path):
        return 'Dokumen tidak ditemukan.', 404
    return send_file(html_path, mimetype='text/html; charset=utf-8', as_attachment=False)


# ======================
# PENTEST LIST + CREATE
# ======================
# @user_bp.route('/pentest')
# def pentest():
#     if not login_required():
#         return redirect(url_for('auth.login'))

#     level = session.get("level")

#     if level == "Internal":
#         page = request.args.get('page', 1, type=int)
#         keyword = request.args.get('keyword', '', type=str)
#         per_page = 5

#         pentests, total = search_pentest_internal(keyword, page, per_page)

#         total_pages = (total + per_page - 1) // per_page

#         return render_template(
#             'internal/pentest.html',
#             pentests=pentests,
#             page=page,
#             total_pages=total_pages,
#             keyword=keyword
#         )

#     # eksternal tetap
#     user_id = session.get("user_id")
#     pentests = get_pentest_by_user(user_id)

#     return render_template('user/pentest.html', pentests=pentests)
@user_bp.route('/pentest')
def pentest():
    if not login_required():
        return redirect(url_for('auth.login'))

    level = session.get("level")

    if level == "Internal":
        keyword = request.args.get('keyword', '', type=str)
        status_filter = request.args.get('status', '', type=str).strip()
        valid_statuses = {'Pending', 'In Progress', 'Done', 'Cancel'}
        if status_filter not in valid_statuses:
            status_filter = ''
        db_error = None
        summary = {"total_assets": 0, "pending": 0, "in_progress": 0, "done": 0, "cancel": 0}
        try:
            pentests = get_pentest_register(keyword)
            summary = get_pentest_register_summary()
            if status_filter:
                pentests = [pentest for pentest in pentests if pentest['pentest_status'] == status_filter]
        except pyodbc.Error:
            # Keep the Pentest page available when the SQL Server is temporarily
            # unreachable. Other modules and their database behavior are untouched.
            pentests = []
            db_error = "Data Pentest belum dapat dimuat karena koneksi database sedang tidak tersedia. Silakan coba lagi beberapa saat lagi."

        return render_template(
            'internal/pentest.html',
            pentests=pentests,
            keyword=keyword,
            summary=summary,
            status_filter=status_filter,
            db_error=db_error
        )

    # eksternal tetap
    user_id = session.get("user_id")
    db_error = None
    try:
        pentests = get_pentest_by_user(user_id)
    except pyodbc.Error:
        pentests = []
        db_error = "Data Pentest belum dapat dimuat karena koneksi database sedang tidak tersedia. Silakan coba lagi beberapa saat lagi."

    return render_template('user/pentest.html', pentests=pentests, db_error=db_error)


# ======================
# CREATE / EDIT (EKSTERNAL ONLY)
# ======================
@user_bp.route('/pentest/edit/<int:id>', methods=['GET', 'POST'])
def edit_pentest(id):
    if not login_required():
        return redirect(url_for('auth.login'))

    user_id = session.get("user_id")

    # CREATE
    if id == 0:
        if request.method == 'POST':
            data = {
                "user_id": user_id,
                "nama_project": request.form["nama_project"],
                "deskripsi": request.form.get("deskripsi"),
                "target_url": request.form.get("target_url"),
                "environment": request.form.get("environment"),
                "start_date": request.form.get("start_date"),
                "end_date": request.form.get("end_date"),
                "link_app": request.form.get("link_app"),
                "link_document": request.form.get("link_document"),
                "catatan_user": request.form.get("catatan_user")
            }
            create_pentest(data)
            return redirect(url_for('user.pentest'))

        return render_template('user/pentest_form.html', pentest=None)

    # EDIT
    pentest = get_pentest_by_id(id)
    if not pentest:
        return redirect(url_for('user.pentest'))

    # 🔒 hanya miliknya
    if pentest["user_id"] != user_id:
        return redirect(url_for('user.pentest'))

    # 🔒 hanya boleh edit saat To_Do
    if pentest["status"] != "To_Do":
        return redirect(url_for('user.pentest'))

    if request.method == 'POST':
        data = {
            "id": id,
            "nama_project": request.form["nama_project"],
            "deskripsi": request.form.get("deskripsi"),
            "target_url": request.form.get("target_url"),
            "environment": request.form.get("environment"),
            "start_date": request.form.get("start_date"),
            "end_date": request.form.get("end_date"),
            "link_app": request.form.get("link_app"),
            "link_document": request.form.get("link_document"),
            "catatan_user": request.form.get("catatan_user")
        }
        update_pentest(data)
        return redirect(url_for('user.pentest'))

    return render_template('user/pentest_form.html', pentest=pentest)


# ======================
# DETAIL
# ======================
@user_bp.route('/pentest/detail/<int:id>')
def pentest_detail(id):
    if not login_required():
        return redirect(url_for('auth.login'))

    pentest = get_pentest_by_id(id)

    if not pentest:
        return redirect(url_for('user.pentest'))

    # 🔥 IZINKAN INTERNAL MELIHAT SEMUA
    if session.get("level") == "Internal":
        return render_template('user/pentest_detail.html', pentest=pentest)

    # EKSTERNAL → hanya miliknya
    if pentest["user_id"] != session.get("user_id"):
        return redirect(url_for('user.pentest'))

    return render_template('user/pentest_detail.html', pentest=pentest)


# ======================
# DELETE (DIMATIKAN)
# ======================
# @user_bp.route('/pentest/delete/<int:id>', methods=['POST'])
# def delete_pentest_route(id):
#     return redirect(url_for('user.pentest'))
@user_bp.route('/pentest/internal/delete/<int:id>', methods=['POST'])
def delete_pentest_internal(id):
    if not login_required():
        return redirect(url_for('auth.login'))

    # 🔒 hanya internal
    if session.get("level") != "Internal":
        return redirect(url_for('user.pentest'))

    delete_pentest_by_id(id)
    return redirect(url_for('user.pentest'))




def is_admin():
    return session.get("level") == "Admin"

def is_internal():
    return session.get("level") == "Internal"

def is_eksternal():
    return session.get("level") == "Eksternal"

@user_bp.route('/pentest/internal/edit/<int:id>', methods=['GET', 'POST'])
def edit_pentest_internal(id):
    if not login_required():
        return redirect(url_for('auth.login'))

    if session.get("level") != "Internal":
        return redirect(url_for('user.pentest'))

    pentest = get_pentest_by_id(id)

    if not pentest:
        return redirect(url_for('user.pentest'))

    users = get_all_users_for_dropdown()
    current_owner = next(
        (user for user in users if user["id"] == pentest["user_id"]),
        None
    )
    owner_value = pentest.get("manual_owner_name") or (
        current_owner["nama"] if current_owner else ""
    )

    if request.method == 'POST':
        owner_name = request.form.get("owner_name", "").strip() or request.form.get("owner_existing", "").strip()

        if not owner_name:
            flash("Owner wajib diisi.", "error")
            return render_template(
                'internal/pentest_edit.html',
                pentest=pentest,
                users=users,
                current_owner=current_owner,
                owner_value=owner_value
            ), 400

        selected_owner = next(
            (user for user in users if user["nama"].casefold() == owner_name.casefold()),
            None
        )

        # Prioritize a typed free-text owner, but if it matches an existing user,
        # use that user record. Otherwise store the typed value in manual_owner_name.
        owner_id = selected_owner["id"] if selected_owner else pentest["user_id"]
        manual_owner_name = None if selected_owner else owner_name

        data = {
            "id": id,
            "user_id": owner_id,
            "manual_owner_name": manual_owner_name,
            "status": request.form.get("status"),
            "start_date": request.form.get("start_date"),
            "end_date": request.form.get("end_date"),
            "link_document": request.form.get("link_document"),
            "catatan_internal": request.form.get("catatan_internal")
        }

        update_pentest_internal(data)
        return redirect(url_for('user.pentest'))

    return render_template(
        'internal/pentest_edit.html',
        pentest=pentest,
        users=users,
        current_owner=current_owner,
        owner_value=owner_value
    )

@user_bp.route('/pentest/internal/create', methods=['GET', 'POST'])
def create_pentest_internal():
    if not login_required():
        return redirect(url_for('auth.login'))

    # 🔒 hanya internal
    if session.get("level") != "Internal":
        return redirect(url_for('user.pentest'))

    if request.method == 'POST':
        report = request.files.get("report_document")
        report_data = {"report_original_name": None, "report_file_path": None, "report_file_type": None, "report_file_size": None}
        if report and report.filename:
            extension = report.filename.rsplit('.', 1)[-1].lower() if '.' in report.filename else ''
            allowed = {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv'}
            if extension not in allowed:
                flash("Format laporan harus PDF, DOC/DOCX, Excel, atau CSV.", "error")
                return redirect(url_for('user.create_pentest_internal'))
            report_dir = os.path.join('uploads', 'pentest')
            os.makedirs(report_dir, exist_ok=True)
            filename = f"PENTEST_{uuid4().hex}.{extension}"
            full_path = os.path.join(report_dir, filename)
            report.save(full_path)
            report_data = {"report_original_name": secure_filename(report.filename), "report_file_path": full_path,
                           "report_file_type": extension, "report_file_size": os.path.getsize(full_path)}

        data = {
            # Kept only for compatibility with the existing pentest_tasks table;
            # the register UI uses Requested as the user-facing submitter field.
            "user_id": session.get("user_id"),
            "requested_by": request.form.get("requested_by", "").strip(),
            "nama_project": request.form.get("nama_project"),
            "menu_items": request.form.get("menu_items"),
            "va_status": request.form.get("va_status"),
            "pentest_status": request.form.get("pentest_status"),
            "pentest_tracker_url": request.form.get("pentest_tracker_url"),
            "date_req": request.form.get("date_req"),
            "date_target": request.form.get("date_target"),
            **report_data,
        }
        try:
            create_pentest_register(data)
        except pyodbc.Error:
            if report_data["report_file_path"] and os.path.isfile(report_data["report_file_path"]):
                os.remove(report_data["report_file_path"])
            flash("Request Pentest belum dapat disimpan. Silakan coba kembali atau hubungi administrator aplikasi.", "error")
            return redirect(url_for('user.create_pentest_internal'))

        # log
        from flask import g
        g.log_action = "CREATE_PENTEST_INTERNAL"
        g.log_detail = f"project={data['nama_project']}"

        flash("Request Pentest berhasil disimpan.", "success")
        return redirect(url_for('user.pentest'))

    return render_template('internal/pentest_create.html')


@user_bp.route('/pentest/internal/report/<int:id>')
def download_pentest_report(id):
    if not login_required() or session.get("level") != "Internal":
        return redirect(url_for('auth.login'))
    report = get_pentest_report(id)
    if not report or not report.report_file_path or not os.path.isfile(report.report_file_path):
        return "Dokumen laporan tidak ditemukan.", 404
    return send_file(report.report_file_path, as_attachment=True, download_name=report.report_original_name)


@user_bp.route('/pentest/internal/view/<int:id>')
def view_pentest_register(id):
    if not login_required() or session.get("level") != "Internal":
        return redirect(url_for('auth.login'))
    pentest = get_pentest_register_by_id(id)
    if not pentest:
        flash("Data Pentest tidak ditemukan.", "error")
        return redirect(url_for('user.pentest'))
    tracker_items = get_pentest_tracker_items(id)
    tracker_progress = round(sum(item['progress'] for item in tracker_items) / len(tracker_items)) if tracker_items else 0
    return render_template('internal/pentest_view.html', pentest=pentest, tracker_items=tracker_items,
                           tracker_progress=tracker_progress)


def _tracker_item_data(form):
    title = form.get('title', '').strip()
    status = form.get('status', 'Planned')
    allowed_statuses = {'Planned', 'In Progress', 'Blocked', 'Completed'}
    if not title:
        raise ValueError('Nama tahapan tracker wajib diisi.')
    if status not in allowed_statuses:
        raise ValueError('Status tracker tidak valid.')
    try:
        progress = int(form.get('progress', 0))
    except (TypeError, ValueError):
        raise ValueError('Progress harus berupa angka antara 0 sampai 100.')
    if not 0 <= progress <= 100:
        raise ValueError('Progress harus bernilai antara 0 sampai 100.')
    return {
        'title': title,
        'status': status,
        'progress': progress,
        'target_date': form.get('target_date') or None,
        'notes': form.get('notes', '').strip() or None,
    }


@user_bp.route('/pentest/internal/tracker/<int:id>')
def pentest_tracker(id):
    if not login_required() or session.get('level') != 'Internal':
        return redirect(url_for('auth.login'))
    pentest = get_pentest_register_by_id(id)
    if not pentest:
        flash('Data Pentest tidak ditemukan.', 'error')
        return redirect(url_for('user.pentest'))
    items = get_pentest_tracker_items(id)
    total_progress = round(sum(item['progress'] for item in items) / len(items)) if items else 0
    completed_items = sum(item['status'] == 'Completed' for item in items)
    return render_template('internal/pentest_tracker.html', pentest=pentest, items=items,
                           total_progress=total_progress, completed_items=completed_items)


@user_bp.route('/pentest/internal/tracker/<int:id>/report.pdf')
def download_pentest_tracker_report(id):
    if not login_required() or session.get('level') != 'Internal':
        return redirect(url_for('auth.login'))
    pentest = get_pentest_register_by_id(id)
    if not pentest:
        flash('Data Pentest tidak ditemukan.', 'error')
        return redirect(url_for('user.pentest'))
    items = get_pentest_tracker_items(id)
    total_progress = round(sum(item['progress'] for item in items) / len(items)) if items else 0
    completed_items = sum(item['status'] == 'Completed' for item in items)
    report = build_pentest_tracker_report(pentest, items, total_progress, completed_items)
    filename = f"pentest_tracker_{id}.pdf"
    return send_file(report, mimetype='application/pdf', as_attachment=True, download_name=filename)


@user_bp.route('/pentest/internal/tracker/<int:id>/items', methods=['POST'])
def create_pentest_tracker_item_route(id):
    if not login_required() or session.get('level') != 'Internal':
        return redirect(url_for('auth.login'))
    if not get_pentest_register_by_id(id):
        flash('Data Pentest tidak ditemukan.', 'error')
        return redirect(url_for('user.pentest'))
    try:
        create_pentest_tracker_item(id, _tracker_item_data(request.form))
        flash('Tahapan tracker berhasil ditambahkan.', 'success')
    except ValueError as error:
        flash(str(error), 'error')
    return redirect(url_for('user.pentest_tracker', id=id))


@user_bp.route('/pentest/internal/tracker/<int:id>/items/<int:item_id>', methods=['POST'])
def update_pentest_tracker_item_route(id, item_id):
    if not login_required() or session.get('level') != 'Internal':
        return redirect(url_for('auth.login'))
    try:
        update_pentest_tracker_item(item_id, id, _tracker_item_data(request.form))
        flash('Tahapan tracker berhasil diperbarui.', 'success')
    except ValueError as error:
        flash(str(error), 'error')
    return redirect(url_for('user.pentest_tracker', id=id))


@user_bp.route('/pentest/internal/tracker/<int:id>/items/<int:item_id>/delete', methods=['POST'])
def delete_pentest_tracker_item_route(id, item_id):
    if not login_required() or session.get('level') != 'Internal':
        return redirect(url_for('auth.login'))
    delete_pentest_tracker_item(item_id, id)
    flash('Tahapan tracker berhasil dihapus.', 'success')
    return redirect(url_for('user.pentest_tracker', id=id))


@user_bp.route('/pentest/internal/edit-register/<int:id>', methods=['GET', 'POST'])
def edit_pentest_register_route(id):
    if not login_required() or session.get("level") != "Internal":
        return redirect(url_for('auth.login'))
    pentest = get_pentest_register_by_id(id)
    if not pentest:
        flash("Data Pentest tidak ditemukan.", "error")
        return redirect(url_for('user.pentest'))
    if request.method == 'POST':
        report = request.files.get('report_document')
        file_data = {"report_original_name": None, "report_file_path": None, "report_file_type": None, "report_file_size": None}
        if report and report.filename:
            extension = report.filename.rsplit('.', 1)[-1].lower() if '.' in report.filename else ''
            if extension not in {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv'}:
                flash("Format laporan harus PDF, DOC/DOCX, Excel, atau CSV.", "error")
                return redirect(request.url)
            report_dir = os.path.join('uploads', 'pentest'); os.makedirs(report_dir, exist_ok=True)
            filename = f"PENTEST_{uuid4().hex}.{extension}"; full_path = os.path.join(report_dir, filename)
            report.save(full_path)
            file_data = {"report_original_name": secure_filename(report.filename), "report_file_path": full_path,
                         "report_file_type": extension, "report_file_size": os.path.getsize(full_path)}
        data = {"requested_by": request.form.get('requested_by', '').strip(), "nama_project": request.form.get('nama_project'),
                "menu_items": request.form.get('menu_items'), "va_status": request.form.get('va_status'),
                "pentest_status": request.form.get('pentest_status'), "pentest_tracker_url": pentest.pentest_tracker_url,
                "date_req": request.form.get('date_req'), "date_target": request.form.get('date_target'), **file_data}
        update_pentest_register(id, data)
        if file_data['report_file_path'] and pentest.report_file_path and os.path.isfile(pentest.report_file_path):
            os.remove(pentest.report_file_path)
        flash("Request Pentest berhasil diperbarui.", "success")
        return redirect(url_for('user.view_pentest_register', id=id))
    return render_template('internal/pentest_edit_register.html', pentest=pentest)


@user_bp.route('/pentest/internal/delete-register/<int:id>', methods=['POST'])
def delete_pentest_register_route(id):
    if not login_required() or session.get("level") != "Internal":
        return redirect(url_for('auth.login'))
    record = delete_pentest_register(id)
    if record and record.report_file_path and os.path.isfile(record.report_file_path):
        os.remove(record.report_file_path)
    flash("Request Pentest berhasil dihapus.", "success")
    return redirect(url_for('user.pentest'))

@user_bp.route('/ip_intelligence')
def ip_intelligence():

    if not login_required():
        return redirect(
            url_for('auth.login')
        )

    page = request.args.get(
        'page',
        1,
        type=int
    )

    keyword = request.args.get(
        'keyword',
        ''
    )

    per_page = 10

    if keyword:

        data, total = search_ip(
            keyword,
            page,
            per_page
        )

    else:

        data, total = get_all_ip(
            page,
            per_page
        )

    summary = get_ip_summary()

    total_pages = (
        total + per_page - 1
    ) // per_page

    return render_template(
        'user/ip_intelligence.html',

        data=data,
        page=page,
        total_pages=total_pages,
        keyword=keyword,

        total_ip=summary["total_ip"],
        total_block=summary["total_block"],
        total_allow=summary["total_allow"]
    )
    
@user_bp.route('/ip_intelligence/upload', methods=['POST'])
def upload_ip():

    if not login_required():
        return redirect(url_for('auth.login'))

    try:

        print("=" * 50)
        print("UPLOAD IP INTELLIGENCE START")
        print("=" * 50)

        file = request.files.get('file')

        if not file:
            print("ERROR: FILE NOT FOUND")
            return redirect(url_for('user.ip_intelligence'))

        print(f"FILE NAME: {file.filename}")

        filename = file.filename.lower()

        # READ FILE
        if filename.endswith('.csv'):

            try:

                df = pd.read_csv(
                    file,
                    sep=';'
                )

            except:

                file.seek(0)

                df = pd.read_csv(file)

        elif filename.endswith('.xlsx') or filename.endswith('.xls'):

            df = pd.read_excel(file)

        else:

            print("ERROR: INVALID FILE FORMAT")

            return redirect(
                url_for('user.ip_intelligence')
            )

        print("ORIGINAL HEADER:")
        print(df.columns.tolist())

        # NORMALIZE HEADER
        df.columns = (
            df.columns
            .str.strip()
            .str.lower()
            .str.replace(" ", "_")
        )

        print("NORMALIZED HEADER:")
        print(df.columns.tolist())

        required_columns = [
            'blacklisted_address',
            'description',
            'status'
        ]

        for col in required_columns:

            if col not in df.columns:

                print(
                    f"ERROR: COLUMN '{col}' NOT FOUND"
                )

                return redirect(
                    url_for('user.ip_intelligence')
                )

        success_count = 0
        failed_count = 0

        for index, row in df.iterrows():

            try:

                blacklisted_address = str(
                    row['blacklisted_address']
                ).strip()

                description = str(
                    row['description']
                ).strip()

                status = str(
                    row['status']
                ).strip()

                print(
                    f"INSERT ROW {index+1}: "
                    f"{blacklisted_address}"
                )

                insert_ip(
                    blacklisted_address,
                    description,
                    status
                )

                success_count += 1

            except Exception as row_error:

                failed_count += 1

                print(
                    f"FAILED ROW {index+1}"
                )

                print(str(row_error))

        print("=" * 50)
        print(
            f"IMPORT FINISHED | "
            f"SUCCESS={success_count} "
            f"FAILED={failed_count}"
        )
        print("=" * 50)

    except Exception as e:

        print("=" * 50)
        print("IMPORT ERROR")
        print("=" * 50)
        print(str(e))

    return redirect(
        url_for('user.ip_intelligence')
    )
    
@user_bp.route('/ip_intelligence/add')
def ip_add():

    if not login_required():
        return redirect(url_for('auth.login'))

    return render_template(
        'user/ip_intelligence_add.html'
    )
    
    
@user_bp.route(
    '/ip_intelligence/save',
    methods=['POST']
)
def ip_save():

    if not login_required():
        return redirect(url_for('auth.login'))

    blacklisted_address = request.form.get(
        'blacklisted_address'
    )

    description = request.form.get(
        'description'
    )

    status = request.form.get(
        'status'
    )

    insert_ip(
        blacklisted_address,
        description,
        status
    )

    return redirect(
        url_for('user.ip_intelligence')
    )
    
@user_bp.route(
    '/ip_intelligence/edit/<int:ip_id>'
)
def ip_edit(ip_id):

    if not login_required():
        return redirect(
            url_for('auth.login')
        )

    ip_data = get_ip_by_id(ip_id)

    return render_template(
        'user/ip_intelligence_edit.html',
        ip=ip_data
    )
    
@user_bp.route(
    '/ip_intelligence/update/<int:ip_id>',
    methods=['POST']
)
def ip_update(ip_id):

    if not login_required():
        return redirect(
            url_for('auth.login')
        )

    update_ip(

        ip_id,

        request.form.get(
            'blacklisted_address'
        ),

        request.form.get(
            'description'
        ),

        request.form.get(
            'status'
        )
    )

    return redirect(
        url_for(
            'user.ip_intelligence'
        )
    )
