import pyodbc
from app.config import Config

def get_connection():
    conn_str = (
        f"DRIVER={Config.DB_CONFIG['DRIVER']};"
        f"SERVER={Config.DB_CONFIG['SERVER']};"
        f"DATABASE={Config.DB_CONFIG['DATABASE']};"
        f"UID={Config.DB_CONFIG['UID']};"
        f"PWD={Config.DB_CONFIG['PWD']}"
    )
    return pyodbc.connect(conn_str)
