import pyodbc

# 1. Konfigurasi Parameter Koneksi
# Sesuaikan isi di dalam tanda kutip dengan data server kamu
server = '192.168.240.22' 
database = 'SEC_PORTAL'
username = 'sa'
password = 'Pythones55!'
driver = '{ODBC Driver 17 for SQL Server}' # Sesuaikan versi driver yang terinstal

# 2. Membuat Connection String
conn_str = f'DRIVER={driver};SERVER={server};DATABASE={database};UID={username};PWD={password}'

def test_connection():
    try:
        print("Sedang mencoba menghubungkan ke database...")
        
        # 3. Membuka Koneksi
        conn = pyodbc.connect(conn_str)
        print("---")
        print("✅ KONEKSI BERHASIL!")
        
        # 4. Tes Query Sederhana (Mengambil Versi SQL Server)
        cursor = conn.cursor()
        cursor.execute("SELECT @@VERSION")
        row = cursor.fetchone()
        
        print(f"Informasi Server:\n{row[0]}")
        
        # 5. Menutup Koneksi
        conn.close()
        print("---")
        print("Koneksi ditutup dengan aman.")

    except pyodbc.Error as e:
        # Jika gagal, tampilkan pesan error
        print("---")
        print("❌ KONEKSI GAGAL!")
        print(f"Pesan Error: {e}")

if __name__ == "__main__":
    test_connection()