import os


def _as_bool(value, default=False):
    return str(value if value is not None else default).strip().lower() in {"1", "true", "yes", "on"}


class Config:
    SECRET_KEY = "secret_key"

    # Network settings can be changed on the server without editing source.
    # 0.0.0.0 listens on every network interface, including the LAN address.
    HOST = os.getenv("SEC_APP_HOST", "0.0.0.0")
    PORT = int(os.getenv("SEC_APP_PORT", "5000"))
    DEBUG = _as_bool(os.getenv("SEC_APP_DEBUG"), default=False)

    # Apply one consistent upload limit to every module.
    MAX_CONTENT_LENGTH = int(os.getenv("SEC_APP_MAX_UPLOAD_MB", "25")) * 1024 * 1024
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _as_bool(os.getenv("SEC_APP_HTTPS"), default=False)

    DB_CONFIG = {
        "DRIVER": "{ODBC Driver 17 for SQL Server}",
        "SERVER": "192.168.240.22",
        "DATABASE": "SEC_PORTAL",
        "UID": "sa",
        "PWD": "Pythones55!"
    }
